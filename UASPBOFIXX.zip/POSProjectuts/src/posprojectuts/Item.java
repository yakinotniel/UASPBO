/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package posprojectuts;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author user
 */
public class Item {
    public String kode;
    public String nama;
    public float harga;
    Date kadaluarsa;
    String operator;
    float nominal;
    
    public static ArrayList<Item> daftarItem = new ArrayList<Item>();
}
    

    

