/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package posprojectuts;

/**
 *
 * @author ASUS
 */
public class POSProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login frame = new Login();
        frame.setVisible(true);
    }
    
}
